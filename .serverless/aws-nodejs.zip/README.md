# www-540-api

This is the repository for the RESTful api used to serve www-540.

Tools: Node.js, Serverless, AWS Lambda, AWS DynamoDB                          
Doc Links: https://nodejs.org/api/ , https://serverless.com/framework/docs/ , http://docs.aws.amazon.com/lambda/latest/dg/welcome.html , https://aws.amazon.com/dynamodb/developer-resources/



